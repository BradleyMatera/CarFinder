// Imports your SCSS stylesheet
import './style.scss';

import data from './data.json'

